# leads-ui
Desktop version of lead sourcing application

## Components   
 - legallead.jsdb : light-weight data store for application meta data
 - legallead.permission.api : api provider for user registration, authentication, permissions